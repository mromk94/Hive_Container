# Encryption Example
Use WebCrypto AES-GCM. See extension_helpers/storage.js