# Persona Compression Spec
See persona_examples for code.